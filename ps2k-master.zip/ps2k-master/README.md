Link-uri utile:

-pagini web componente:
Motor:
https://create.arduino.cc/projecthub/debanshudas23/getting-started-with-stepper-motor-28byj-48-3de8c9
https://lastminuteengineers.com/28byj48-stepper-motor-arduino-tutorial/
https://www.makerguides.com/28byj-48-stepper-motor-arduino-tutorial/ 
Senzor IR:
http://irsensor.wizecode.com/
Ecran LCD 1602A:
https://www.instructables.com/How-to-Connect-I2C-Lcd-Display-to-Arduino-Uno/
Sursa:
https://www.cafago.com/en/p-e8575.html
Vending machine proiect:
https://howtomechatronics.com/projects/diy-vending-machine-arduino-based-mechatronics-project/?fbclid=IwAR3ts-Tje6CGv24YsQDtjpNGxdEqIPLoj2BMx5A6ZengF8q_Q8aGKdhb3qY 
https://ocw.cs.pub.ro/courses/pm/prj2019/dionita/420

-filmulete youtube proiect:
Sortare bani:
https://www.youtube.com/watch?v=RP_ADPMHKFs&t=15s
https://www.youtube.com/watch?v=yvIyf5E1BDY&t=39s
https://www.youtube.com/watch?v=CasXSwXbm2Y 
https://www.youtube.com/watch?v=4ZLjvlN6iL0&list=WL&index=49&t=1s
Vending machine:
https://www.youtube.com/watch?v=7gW1hmYqdwo – doze
https://www.youtube.com/watch?v=-gdm71P1k9c
https://www.youtube.com/watch?v=BHQBsswUeT0&t=51s 

-Comunicatie Arduino:
 https://iot-guider.com/arduino/serial-communication-between-two-arduino-boards/

-link drive poze:
https://drive.google.com/drive/folders/1JTVlETm6O9kBB_9Mifwj4YpqvGJlTPdQ?usp=sharing
